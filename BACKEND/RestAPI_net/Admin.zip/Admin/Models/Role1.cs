﻿using System;
using System.Collections.Generic;

namespace Admin.Models;

public partial class Role1
{
    public int Rid { get; set; }

    public string? Rname { get; set; }
}
