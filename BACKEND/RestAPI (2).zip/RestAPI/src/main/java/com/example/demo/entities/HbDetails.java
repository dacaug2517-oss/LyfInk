
package com.example.demo.entities;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="hb_details")
@Getter
@Setter
public class HbDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int hbid;
    @Column(name = "hb_name")
    private String name;        // ✅ renamed
    @Column(name = "hb_email")
    private String email;       // ✅ renamed (important)

    private String password;    // ✅ added
    @Column(name = "hb_phno")
    private String phone;       // ✅ renamed
    @Column(name = "reg_no")
    private String regNo;
    @Column(name = "gst_no")
    private String gstNo;

    private String type;

    @OneToOne
    @JoinColumn(name="uid")
    private Users user;
}
