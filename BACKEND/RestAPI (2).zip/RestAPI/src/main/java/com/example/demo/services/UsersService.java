package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DTO.RegisterRequest;
import com.example.demo.entities.*;
import com.example.demo.repositories.*;

@Service
public class UsersService {

    @Autowired UsersRepository userRepo;
    @Autowired RoleRepository roleRepo;
    @Autowired StateRepository stateRepo;
    @Autowired CityRepository cityRepo;

    // ✅ Needed for Blood Component
    @Autowired BloodComponentRepository bloodComponentRepo;

    // ✅ ADD THIS for Hospital/BloodBank Login
    @Autowired HbDetailsRepository hbDetailsRepo;

    // ===========================
    // ✅ REGISTER (UNCHANGED)
    // ===========================
    public Users register(RegisterRequest req) {

        Role role = roleRepo.findById(req.getRid()).orElseThrow();
        State state = stateRepo.findById(req.getStateid()).orElseThrow();
        City city = cityRepo.findById(req.getCityid()).orElseThrow();

        Users user = new Users();
        user.setFirstname(req.getFirstname());
        user.setLastname(req.getLastname());
        user.setEmail(req.getEmail());
        user.setPassword(req.getPassword());
        user.setMobno(req.getMobno());
        user.setAddress(req.getAddress());

        user.setSecurity_question(req.getSecurity_question());
        user.setSecurity_answer(req.getSecurity_answer());

        user.setRole(role);
        user.setState(state);
        user.setCity(city);

        // ✅ Donor Registration
        if (req.getRid() == 1 && req.getDonorDetails() != null) {

            Donor donor = new Donor();
            donor.setDob(req.getDonorDetails().getDob());
            donor.setGender(req.getDonorDetails().getGender());
            donor.setMedical_history(req.getDonorDetails().getMedical_history());

            // ✅ Fetch BloodComponent Object using bcid
            BloodComponent bc =
                    bloodComponentRepo.findById(req.getDonorDetails().getBcid())
                    .orElseThrow(() -> new RuntimeException("Invalid Blood Component"));

            donor.setBloodComponent(bc);

            donor.setUser(user);
            user.setDonor(donor);
        }

        // ✅ Hospital Registration
        if (req.getRid() == 2 && req.getHbDetails() != null) {

            HbDetails hb = new HbDetails();

            // ⚠️ Keep your existing setters exactly
            hb.setName(req.getHbDetails().getHb_name());
            hb.setEmail(req.getHbDetails().getHb_email());
            hb.setPhone(req.getHbDetails().getHb_phno());
            hb.setRegNo(req.getHbDetails().getReg_no());
            hb.setGstNo(req.getHbDetails().getGst_no());
            hb.setType(req.getHbDetails().getType());

            // ✅ Add password also
            hb.setPassword(req.getHbDetails().getPassword());

            hb.setUser(user);
            user.setHb(hb);
        }

        return userRepo.save(user);
    }

    // ===========================
    // ✅ LOGIN METHOD (ADDED ONLY)
    // ===========================
    public Object loginUser(String email, String password) {

        // 1️⃣ Check Users table (Admin + Donor)
        Users user = userRepo.findByEmail(email);

        if (user != null) {
            if (user.getPassword().equals(password)) {
                return user;
            }
            throw new RuntimeException("Invalid password!");
        }

        // 2️⃣ Check Hospital/BloodBank table
        HbDetails hb = hbDetailsRepo.findByEmail(email);

        if (hb != null) {
            if (hb.getPassword().equals(password)) {
                return hb;
            }
            throw new RuntimeException("Invalid password!");
        }

        throw new RuntimeException("Account not found!");
    }
}
